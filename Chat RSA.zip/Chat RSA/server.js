const http = require("http");
const socketIo = require("socket.io");
const crypto = require("crypto");

const server = http.createServer();
const io = socketIo(server);

// Maintain a list of users and their public keys
const userKeys = new Map();

// Handle new client connections
io.on("connection", (client) => {
  console.log(`New client connected: ${client.id}`);

  // Send existing user list to the new client
  client.emit("userList", Array.from(userKeys.entries()));

  // Handle public key registration from the client
  client.on("registerKey", ({ name, publicKey }) => {
    userKeys.set(name, publicKey);
    console.log(`${name} has registered their public key.`);
    io.emit("newUser", { name, publicKey });
  });

  // Handle incoming messages and broadcast to others
  client.on("message", ({ name, text, signature, isImpersonating }) => {
    if (!signature || !text) {
      console.log(`WARNING: Suspicious message from ${name}`);
      return;
    }

    // Check the public key for the sender
    const senderPublicKey = userKeys.get(name);
    if (!senderPublicKey) {
      console.log(`WARNING: Public key not found for ${name}`);
      return;
    }

    // Verify the signature
    const isValid = verifySignature(senderPublicKey, text, signature);
    if (!isValid) {
      console.log(`${name}: ${text} (WARNING: Invalid signature, possible impersonation!)`);

      // Send the invalid message warning to other clients, not the sender
      client.broadcast.emit("message", {
        name: name,
        text: `${text} `,
        signature,
      });

      return;
    }

    // If impersonating, don't include the sender's name in the message
    if (isImpersonating) {
      client.broadcast.emit("message", { text, signature });
    } else {
      client.broadcast.emit("message", { name, text, signature });
    }
  });

  // Handle client disconnection
  client.on("disconnect", () => {
    console.log(`Client disconnected: ${client.id}`);
  });
});

// Function to verify the signature
function verifySignature(publicKey, message, signature) {
  try {
    const signatureBuffer = Buffer.from(signature, "base64");
    const isVerified = crypto.verify(
      "sha256",
      Buffer.from(message),
      { key: publicKey, format: "pem", type: "spki" },
      signatureBuffer
    );
    return isVerified;
  } catch (error) {
    console.error("Error verifying signature:", error);
    return false;
  }
}

// Start the server
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Chat server is running on port ${PORT}`);
});
