const httpServer = require("http");
const socketIO = require("socket.io"); 
const cryptoModule = require("crypto"); 

const server = httpServer.createServer();
const io = socketIO(server);

const clientData = new Map(); 

io.on("connection", (clientSocket) => {///Menangani Koneksi Pengguna dan Pendaftaran Kunci
  console.log(`Client ${clientSocket.id} has connected`);///Server menerima username dan publicKey dari klien

  clientSocket.emit("init", Array.from(clientData.entries())); 

  clientSocket.on("registerKey", (data) => { 
    const { username, publicKey } = data;
    clientData.set(username, { id: clientSocket.id, publicKey }); 
    console.log(`${username} registered their public key.`);

    io.emit("userJoined", { username, publicKey }); ///Server menyimpan data ini dalam clientData dan mengirimkan informasi ke semua klien lain yang terhubung, 
                                                      ///memberi tahu bahwa pengguna baru telah bergabung (userJoined).
  });

  clientSocket.on("broadcastMessage", (data) => { ///Mengirim Pesan:server akan meneruskan pesan tersebut ke semua klien yang terhubung.
    const { username, message } = data;
    io.emit("broadcastMessage", { username, message });
  });

  clientSocket.on("privateMessage", (data) => { ///private pesan server akan mencari target pengguna. Jika ditemukan, server akan mengirimkan
    /// pesan terenkripsi kepada pengguna target. Jika target tidak ditemukan, server akan mengirimkan pesan kesalahan.
    const { sender, target, message } = data;
    const targetClient = clientData.get(target); 

    if (targetClient) { 
      io.to(targetClient.id).emit("privateMessage", { sender, target, message });

      clientData.forEach((info, user) => {
        if (user !== sender && user !== target) {
          io.to(info.id).emit("privateMessage", { sender, target, message });
        }
      });
    } else {
      clientSocket.emit("error", `User ${target} not found.`);
    }
  });

  clientSocket.on("disconnect", () => {
    console.log(`Client ${clientSocket.id} has disconnected`);
    clientData.forEach((info, user) => {
      if (info.id === clientSocket.id) {
        clientData.delete(user);
        io.emit("userLeft", { username: user });
        console.log(`${user} has disconnected`);
      }
    });
  });
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
