const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let username = "";

// Function to generate a hash of a message
function generateHash(message) {
  return crypto.createHash("sha256").update(message).digest("hex");
}

socket.on("connect", () => {
  console.log("Connected to the server");

  rl.question("Enter your username: ", (input) => {
    username = input;
    console.log(`Welcome, ${username} to the chat`);
    rl.prompt();

    rl.on("line", (message) => {
      if (message.trim()) {
        const messageHash = generateHash(message);
        // Send the message along with its hash to the server
        socket.emit("message", { username, message, messageHash });
      }
      rl.prompt();
    });
  });
});

// Handle incoming messages
socket.on("message", (data) => {
  const { username: senderUsername, message: senderMessage, messageHash } = data;

  // Generate the hash for the received message
  const receivedHash = generateHash(senderMessage);

  // Display the received message
  console.log(`${senderUsername}: ${senderMessage}`);

  // Check if the hash matches
  if (receivedHash !== messageHash) {
    console.log("⚠️ Warning: The message may have been altered during transmission!");
  }

  rl.prompt(); // Ensure the prompt appears after displaying the received message
});

// Handle server disconnection
socket.on("disconnect", () => {
  console.log("Server disconnected, Exiting...");
  rl.close();
  process.exit(0);
});

// Handle SIGINT (Ctrl+C)
rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});
