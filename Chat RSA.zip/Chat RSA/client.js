// Load necessary modules
const socketClient = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

// Connect to server
const socket = socketClient("http://localhost:3000");

// Setup user input handling
const inputHandler = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

// Generate RSA key pair for the client
const { privateKey: userPrivateKey, publicKey: userPublicKey } = crypto.generateKeyPairSync("rsa", {
  modulusLength: 2048,
  publicKeyEncoding: { type: "spki", format: "pem" },
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
});

// Initialize variables to track user state
let currentUser = "";
let realUsername = "";  // The real username of the client
const knownUsers = new Map();

// When connected to the server
socket.on("connect", () => {
  console.log("Connected to the chat server.");

  // Ask for username on startup
  inputHandler.question("Enter your username: ", (name) => {
    currentUser = name;
    realUsername = name;

    // Menghubungi Server dan Mendaftar Nama Pengguna dan Kunci Publik
    socket.emit("registerKey", { name, publicKey: userPublicKey });
    console.log(`Welcome, ${name}! You are now in the chat.`);

    // Start accepting input for chat messages
    inputHandler.prompt();
    inputHandler.on("line", (line) => {
      if (line.startsWith("!impersonate")) {
        // Command to impersonate another user
        const targetName = line.split(" ")[1];
        if (targetName) {
          currentUser = targetName;
          console.log(`You are now pretending to be ${targetName}`);
        }
      } else if (line === "!exit") {
        // Command to stop impersonating
        currentUser = realUsername;
        console.log(`You are now yourself (${realUsername}) again.`);
      } else {
        // Sign and send messages to the server
        const signature = crypto
          .sign("sha256", Buffer.from(line), userPrivateKey)
          .toString("base64");
        socket.emit("message", { name: currentUser, text: line, signature });
      }
      inputHandler.prompt();
    });
  });
});

// Handle incoming user list
socket.on("userList", (users) => {
  users.forEach(([name, key]) => knownUsers.set(name, key));
  console.log(`Currently, there are ${knownUsers.size} users in the chat.`);
  inputHandler.prompt();
});

// Notify when a new user joins
socket.on("newUser", ({ name, publicKey }) => {
  knownUsers.set(name, publicKey);
  console.log(`${name} has joined the chat.`);
  inputHandler.prompt();
});

// Process incoming messages
socket.on("message", ({ name, text, signature }) => {
  const senderKey = knownUsers.get(name);

  // Check if the message has no signature or no public key for the sender
  if (!signature || !senderKey) {
    console.log(`${name}: ${text} (WARNING: Possible impersonation!)`);
    inputHandler.prompt();
    return;
  }

  // Verify the message's signature
  try {
    const isVerified = crypto.verify(
      "sha256",
      Buffer.from(text),
      { key: senderKey, format: "pem", type: "spki" },
      Buffer.from(signature, "base64")
    );

    if (isVerified) {
      // If the message is from the current user, don't show the username
      if (name === realUsername) {
        console.log(text); // Just show the message, not the username
      } else {
        console.log(`${name}: ${text}`); // Show username for other users
      }
    } else {
      console.log(`${name}: ${text} (WARNING: Invalid signature, possible impersonation!)`);
    }
  } catch (err) {
    console.error(`Error verifying message from ${name}: ${err.message}`);
  }

  inputHandler.prompt();
});

// Handle server disconnection
socket.on("disconnect", () => {
  console.log("Server disconnected. Exiting...");
  inputHandler.close();
  process.exit(0);
});
